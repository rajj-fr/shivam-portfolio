INSTAFFIX CINEMATIC PORTFOLIO
1. Open index.html in Chrome to preview.
2. Replace the WhatsApp number in index.html (search for 910000000000).
3. Replace service text, portfolio labels and branding as needed.
4. Upload index.html to any static hosting service.
